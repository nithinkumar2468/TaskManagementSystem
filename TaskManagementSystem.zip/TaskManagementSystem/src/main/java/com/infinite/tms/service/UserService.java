package com.infinite.tms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.infinite.tms.model.UserDTO;
import com.infinite.tms.model.Users;
import com.infinite.tms.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private PasswordEncoder Encoder;

	public Users saveUser(UserDTO userDto) {
		// TODO Auto-generated method stub
		Users user=new Users();
		user.setName(userDto.getName());
		user.setEmail(userDto.getEmail());
		user.setPassword(Encoder.encode(userDto.getPassword()));
		return userRepo.save(user);	
	}

}

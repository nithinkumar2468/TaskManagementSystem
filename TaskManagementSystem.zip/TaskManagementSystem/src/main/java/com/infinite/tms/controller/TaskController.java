package com.infinite.tms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infinite.tms.model.Task;
import com.infinite.tms.model.TaskDTO;
import com.infinite.tms.service.TaskService;

@RestController
@RequestMapping("/api")
public class TaskController {

	@Autowired
	private TaskService taskService;

	@PostMapping("/{userid}/tasks")
	public Task createTasks(@PathVariable long userid, @RequestBody TaskDTO taskDto) {
		return taskService.saveTasks(userid, taskDto);
	}

	@GetMapping("/{userid}/getall")
	public List<TaskDTO> AllTasks(@PathVariable("userid") long userid) {
		return taskService.getAllTasks(userid);
	}

	@GetMapping("/{userid}/get/{tid}")
	public TaskDTO TaskById(@PathVariable("userid") Long userid, @PathVariable("tid") Long tid) {
		return taskService.findByTaskId(userid, tid);
	}

	@DeleteMapping("/{userid}/delete/{tid}")
	public String DeleteTask(@PathVariable("userid") Long userid, @PathVariable("tid") Long tid) {
		return taskService.deletetaskbyId(userid, tid);
	}

}

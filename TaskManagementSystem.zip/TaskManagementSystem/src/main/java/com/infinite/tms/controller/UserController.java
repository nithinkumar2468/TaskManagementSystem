package com.infinite.tms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infinite.tms.model.JWTAuthResponse;
import com.infinite.tms.model.LoginDTO;
import com.infinite.tms.model.UserDTO;
import com.infinite.tms.model.Users;
import com.infinite.tms.security.TokenProvider;
import com.infinite.tms.service.UserService;

@RestController
@RequestMapping("/api/auth")
public class UserController {
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private TokenProvider provider;
	
	@PostMapping("/register")
	public Users createUser(@RequestBody UserDTO user)
	{
		return userService.saveUser(user);
	}
	
	@PostMapping("/login")
	public ResponseEntity<JWTAuthResponse> loginUser(@RequestBody LoginDTO loginDto){
		Authentication authentication=
				authenticationManager.authenticate(
						new UsernamePasswordAuthenticationToken(loginDto.getEmail(),loginDto.getPassword()));
		System.out.println(authentication);
		SecurityContextHolder.getContext().setAuthentication(authentication);
		
		String token=provider.generateToken(authentication);
				
		return ResponseEntity.ok(new JWTAuthResponse(token));
	}

}

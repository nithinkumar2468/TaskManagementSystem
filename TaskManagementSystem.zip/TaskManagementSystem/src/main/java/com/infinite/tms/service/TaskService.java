package com.infinite.tms.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.tms.exception.APINotFoundException;
import com.infinite.tms.exception.TaskNotFoundException;
import com.infinite.tms.exception.UserNotFoundException;
import com.infinite.tms.model.Task;
import com.infinite.tms.model.TaskDTO;
import com.infinite.tms.model.Users;
import com.infinite.tms.repository.TaskRepository;
import com.infinite.tms.repository.UserRepository;

@Service
public class TaskService {

	@Autowired
	private ModelMapper modelMapper;

	@Autowired
	private TaskRepository taskRepo;

	@Autowired
	private UserRepository userRepo;

	public Task saveTasks(long userid, TaskDTO taskDto) {
		// TODO Auto-generated method stub
		Users Id = userRepo.findById(userid).orElseThrow(() -> new UserNotFoundException(userid));
		Task task = new Task();
		task.setTaskname(taskDto.getTaskname());
		task.setUsers(Id);
		return taskRepo.save(task);
	}

	public List<TaskDTO> getAllTasks(long userid) {
		// TODO Auto-generated method stub
		Users Id = userRepo.findById(userid).orElseThrow(() -> new UserNotFoundException(userid));

		List<Task> tasks = taskRepo.findAllByUsersId(userid);

		return tasks.stream().map(task -> modelMapper.map(task, TaskDTO.class)).collect(Collectors.toList());
	}

	public TaskDTO findByTaskId(Long id, Long tid) {
		// TODO Auto-generated method stub
		Users users = userRepo.findById(id).orElseThrow(() -> new UserNotFoundException(id));

		Task task=taskRepo.findById(tid).orElseThrow(()->new TaskNotFoundException(tid));
		
		if(users.getId()!=task.getUsers().getId()) {
			throw new APINotFoundException(String.format("Task Id %d is not belongs to User Id %d", tid, id));
		}
		
		return modelMapper.map(task, TaskDTO.class);
	}

	public String deletetaskbyId(Long userid, Long tid) {
		// TODO Auto-generated method stub
		Users users = userRepo.findById(userid).orElseThrow(() -> new UserNotFoundException(userid));

		Task task=taskRepo.findById(tid).orElseThrow(()->new TaskNotFoundException(tid));
		if(users.getId()!=task.getUsers().getId()) {
			throw new APINotFoundException(String.format("Task Id %d is not belongs to User Id %d", tid, userid));
		}
		taskRepo.deleteById(tid);
		return "Deleted Successfully";
	}
}

/*
 * List<Task> tasks = taskRepo.findAllByUsersId(id);
 * 
 * Task task = new Task(); if (tasks != null) { for (Task taskid : tasks) { if
 * (taskid.getId() == tid) { task = taskRepo.findById(tid).get(); } } } else {
 * throw new
 * APINotFoundException(String.format("Task Id %d is not belongs to User Id %d",
 * tid, id)); }
 */

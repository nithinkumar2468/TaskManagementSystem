package com.infinite.tms.model;

public class JWTAuthResponse {
	private String token;
	private String tokenType="Bearer";
	public String getToken() {
		return token;
	}
	public String getTokenType() {
		return tokenType;
	}
	public JWTAuthResponse(String token) {
		super();
		this.token = token;
	}
	
}

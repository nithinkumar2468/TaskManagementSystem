package com.infinite.tms.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class APINotFoundException extends RuntimeException{
	private  String message;

	public APINotFoundException(String message) {
		super(message);
		this.message = message;
	}

}
